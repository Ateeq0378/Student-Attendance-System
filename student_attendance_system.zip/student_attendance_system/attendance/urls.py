from attendance import views
from django.contrib import admin
from django.urls import path

urlpatterns =[
    path('', views.indexPage, name="index"),
    path('admin-home/', views.adminHomePage, name="admin-home"),
    path('admin-attendance/', views.adminAttendancePage, name="admin-attendance"),
    path('admin-department/', views.adminDepartmentPage, name="admin-department"),
    path('admin-course/', views.adminCoursePage, name="admin-course"),
    path('admin-faculty/', views.adminFacultyPage, name="admin-faculty"),
    path('admin-class/', views.adminClassPage, name="admin-class"),
    path('admin-student/', views.adminStudentPage, name="admin-student"),
    path('admin-attendance-details/', views.adminAttendanceDetailsPage, name="admin-attendance-details"),
    path('faculty-home/', views.facultyHomePage, name="faculty-home"),
    path('faculty-attendance/', views.facultyAttendancePage, name="faculty-attendance"),
    path('faculty-student/', views.facultyStudentPage, name="faculty-student"),
    path('faculty-attendance-details/', views.facultyAttendanceDetailsPage, name="faculty-attendance-details"),
    path('faculty-take-attendance/', views.facultyTakeAttendancePage, name="faculty-take-attendance"),
]