from django.db import models

# Create your models here.

class administrator(models.Model):
    name = models.CharField(max_length = 50)
    gmailId = models.CharField(max_length = 50)
    mobileNo = models.CharField(max_length = 10)

class department(models.Model):
    departmentName = models.CharField(max_length = 20)
    description = models.CharField(max_length = 50)

class faculty(models.Model):
    mame = models.CharField(max_length = 50)
    designation = models.CharField(max_length = 50)
    gmailId = models.CharField(max_length = 50)
    mobileNo = models.CharField(max_length = 50)
    departmentId = models.ForeignKey(department, on_delete = models.CASCADE)

class courseType(models.Model):
    courseType = models.CharField(max_length = 2)

class course(models.Model):
    courseName = models.CharField(max_length = 20)
    description = models.CharField(max_length = 50)
    departmentId = models.ForeignKey(department, on_delete = models.CASCADE)
    courseTypeId = models.ForeignKey(courseType, on_delete = models.CASCADE)

class semester(models.Model):
    semester = models.CharField(max_length = 2)

class student(models.Model):
    studentName = models.CharField(max_length = 50)
    courseId = models.ForeignKey(course, on_delete = models.CASCADE)
    semesterId = models.ForeignKey(semester, on_delete = models.CASCADE)

class subject(models.Model):
    subjectName = models.CharField(max_length = 50)
    courseId = models.ForeignKey(course, on_delete = models.CASCADE)
    semesterId = models.ForeignKey(semester, on_delete = models.CASCADE)

class attendance(models.Model):
    studentRollNo = models.ForeignKey(student, on_delete = models.CASCADE)
    subjectId = models.ForeignKey(subject, on_delete = models.CASCADE)
    action = models.CharField(max_length = 1)
    date = models.DateField()