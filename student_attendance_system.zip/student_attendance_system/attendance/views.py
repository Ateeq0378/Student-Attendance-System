from django.shortcuts import render, redirect
from django.http import HttpResponse, HttpResponseRedirect

# Create your views here.

def indexPage(request):
    return render(request,"index.html")

def adminHomePage(request):
    return render(request,"admin-home.html")

def adminAttendancePage(request):
    return render(request,"admin-attendance.html")

def adminDepartmentPage(request):
    return render(request,"admin-department.html")

def adminCoursePage(request):
    return render(request,"admin-course.html")

def adminFacultyPage(request):
    return render(request,"admin-faculty.html")

def adminClassPage(request):
    return render(request,"admin-class.html")

def adminStudentPage(request):
    return render(request,"admin-student.html")

def adminAttendanceDetailsPage(request):
    return render(request,"admin-attendance-details.html")

def facultyHomePage(request):
    return render(request,"faculty-home.html")

def facultyAttendancePage(request):
    return render(request,"faculty-attendance.html")

def facultyStudentPage(request):
    return render(request,"faculty-student.html")

def facultyAttendanceDetailsPage(request):
    return render(request,"faculty-attendance-details.html")

def facultyTakeAttendancePage(request):
    return render(request,"faculty-take-attendance.html")